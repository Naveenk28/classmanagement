from django.db import models



class students(models.Model):
    id=models.AutoField(primary_key=True)
    StudentID=models.IntegerField('Student ID',unique=True)
    FirstName=models.CharField('First Name',max_length=50)
    LastName=models.CharField('Last Name',max_length=50)
    DateOfBirth=models.CharField('Date Of Birth',max_length=50)
    Address=models.CharField('Address',max_length=200)
    ContactNumber=models.IntegerField('Contact Number')
    Email=models.CharField('Email',max_length=50)
    class Meta:
        db_table='students'

class teachers(models.Model):
    id=models.AutoField(primary_key=True)
    TeacherID=models.IntegerField('Teacher ID',unique=True)
    FirstName=models.CharField('First Name',max_length=50)
    LastName=models.CharField('Last Name',max_length=50)
    DateOfBirth=models.CharField('Date Of Birth',max_length=50)
    Address=models.CharField('Address',max_length=200)
    ContactNumber=models.IntegerField('Contact Number')
    Email=models.CharField('Email',max_length=50)
    class Meta:
        db_table='teachers'

class subjects(models.Model):
    id=models.AutoField(primary_key=True)
    SubjectID=models.IntegerField('Subject ID',unique=True)
    SubjectName=models.CharField('Subject Name',max_length=50)
    class Meta:
        db_table='subjects'

class marks(models.Model):
    MarkID=models.IntegerField('Mark ID')
    StudentID=models.ForeignKey(
        students, 
        on_delete=models.CASCADE, 
        to_field='StudentID'
        )
    SubjectID=models.ForeignKey(
        subjects,
        on_delete=models.CASCADE,
        to_field='SubjectID'
        )
    TeacherID=models.ForeignKey(
        teachers, 
        on_delete=models.CASCADE, 
        to_field='TeacherID'
        )
    MarkObtained=models.IntegerField('Mark Obtained')
    ExamDate=models.DateField('Exam Date')
    class Meta:
        db_table='marks'
