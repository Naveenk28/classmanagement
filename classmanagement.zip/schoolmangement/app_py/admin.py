from django.contrib import admin
from .models import marks,students,subjects,teachers
from import_export.admin import ImportExportModelAdmin

@admin.register(marks)
@admin.register(students)
@admin.register(teachers)
@admin.register(subjects)

class userdata(ImportExportModelAdmin):
    pass
