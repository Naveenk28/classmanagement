from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponse as htt
from .models import students,marks,subjects,teachers
from django import forms

def home(request):
    return render(request,"./home.html")

def studentlogin(request):
    return render(request,"./student.html") 

def teacherlogin(request):
    return render(request,"./teachers.html")

def studentdetail(request):
    # Fetch all students
    all_students = students.objects.all()
    return render(request, 'studentdetail.html', {'students': all_students})

def allresults(request):
    # Fetch all marks with related data
    marks_data = marks.objects.select_related('StudentID', 'SubjectID', 'TeacherID').all()

    # Pass data to the template
    context = {
        'marks_data': marks_data,
    }
    return render(request, 'allresults.html', context)

def addmarks(request):
    subject_data = [
        (subject.SubjectName, subject.id, subject.SubjectID)
        for subject in subjects.objects.all()
    ]
    return render(request, 'add_student_and_marks.html', {'subjects': subject_data})

def studentresult(request):
    studentid=request.POST['sid']
        # Fetch the student by StudentID
    student = students.objects.get(StudentID=studentid)

    # Fetch the subjects and marks for the student
    student_marks = marks.objects.filter(StudentID=student)

    # Prepare the data for rendering
    subjects_marks = []
    for mark in student_marks:
        subject = subjects.objects.get(SubjectID=mark.SubjectID.SubjectID)
        subjects_marks.append({
                'subject_name': subject.SubjectName,
                'mark_obtained': mark.MarkObtained,
                'exam_date': mark.ExamDate
        })

    return render(request, 'studentresult.html',context= {
            'student': student,
            'subjects_marks': subjects_marks
        })       

class MarksForm(forms.ModelForm):
    class Meta:
        model = marks
        fields = ['MarkID', 'StudentID', 'SubjectID', 'TeacherID', 'MarkObtained', 'ExamDate']


def add_marks(request):
    if request.method == "POST":
        try:
            student_id = request.POST['student_id']
            
            for subject in subjects.objects.all():
                last_mark = marks.objects.last()
                mark_id = last_mark.MarkID + 1 if last_mark else 1
                subject_id = subject.SubjectID
                teacher_id = subject.id  # Assuming TeacherID is mapped per subject
                    
                    # Fetch the marks and exam date
                mark_obtained = request.POST[f'mark_obtained_{subject_id}']
                exam_date = request.POST[f'exam_date_{subject_id}']

                    # Insert into marks table
                marks.objects.create(
                        MarkID=mark_id,
                        StudentID_id=student_id,
                        SubjectID_id=subject_id,
                        TeacherID_id=teacher_id,
                        MarkObtained=mark_obtained,
                        ExamDate=exam_date
                    )
            return htt("Marks successfully added.")
        except Exception as e:
            return htt(f"An error occurred: {e}")

    # Prepare subject-teacher data
    subject_data = [
        (subject.SubjectName, subject.id, subject.SubjectID)
        for subject in subjects.objects.all()
    ]
    return render(request, 'add_student_and_marks.html', {'subjects': subject_data})
    


# View to handle form submission
def add_student(request):
    if request.method == 'POST':
        # Collect data from the form
        student_id = request.POST['StudentID']
        first_name = request.POST['FirstName']
        last_name = request.POST['LastName']
        date_of_birth = request.POST['DateOfBirth']
        address = request.POST['Address']
        contact_number = request.POST['ContactNumber']
        email = request.POST['Email']

        # Insert data into the students table

        new_student = students(
                StudentID=student_id,
                FirstName=first_name,
                LastName=last_name,
                DateOfBirth=date_of_birth,
                Address=address,
                ContactNumber=contact_number,
                Email=email
            )
        new_student.save()
        return htt("Student added successfully!")  # Simple response for successy

    # Render the form for GET requests
    return htt('addded student')

def delete_student(request):
    return render(request,'deletestudents_marks.html')

def delete_student_and_marks(request):
    if request.method == "POST":
        student_id = request.POST.get('student_id')

        try:
            # Use transaction to ensure both deletions happen atomically
                # Delete associated marks
                marks_deleted = marks.objects.filter(StudentID_id=student_id).delete()

                # Delete the student record
                student_deleted = students.objects.filter(StudentID=student_id).delete()

                if student_deleted[0] == 0:  # Check if no student record was deleted
                    return htt(f"No student found with StudentID: {student_id}")
                
                return htt(
                    f"Successfully deleted student (ID: {student_id}) and {marks_deleted[0]} related marks."
                )
        except Exception as e:
            return htt(f"An error occurred: {e}")

    # Render the delete student form
    return render(request, 'deletestudents_marks.html')


def modifymarks(request):
    return render(request,'modifyallsubjectmarks.html')

def modify_allsubjectmarks(request):
    if request.method == "POST":
        student_id = request.POST.get('student_id')
        student_marks = marks.objects.filter(StudentID__StudentID=student_id).select_related('SubjectID')
        student=students.objects.get(StudentID=student_id)
        return render(request, 'updatemark.html', {
            'student_id': student_id,
            'student_marks': student_marks,
            'student':student,
        })
        
    return render(request, 'updatemark.html')



def updateallsubjectmarks(request):
    if request.method == 'POST':
        student_id = request.POST.get('student_id')
        marks_data = request.POST.getlist('marks[]')
        exam_dates = request.POST.getlist('exam_dates[]')
        subject_ids = request.POST.getlist('subject_ids[]')

        # Update marks for each subject
        for idx, subject_id in enumerate(subject_ids):
            mark_entry = get_object_or_404(marks, StudentID__StudentID=student_id, SubjectID__SubjectID=subject_id)
            mark_entry.MarkObtained = marks_data[idx]
            mark_entry.ExamDate = exam_dates[idx]
            mark_entry.save()

        return redirect('modifymarks')  # Redirect after saving changes
