"""
URL configuration for schoolmangement project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from app_py import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home),
    path('studentlogin/',views.studentlogin),
    path('studentlogin/studentresult/',views.studentresult),
    path('teacherslogin/',views.teacherlogin),
    path('teacherslogin/studentdetail/',views.studentdetail),
    path('teacherslogin/allresults/',views.allresults),
    path('teacherslogin/addmarks/',views.addmarks, name='add_student_and_marks'),
    path('teacherslogin/addmarks/add_student_and_marks/',views.add_student, name='add_student'),
    path('teacherslogin/addmarks/add_marks/',views.add_marks, name='add_marks'),
    path('teacherslogin/deletemarks/',views.delete_student),
    path('teacherslogin/deletemarks/delete_student_and_marks/',views.delete_student_and_marks, name='delete_marks'),
    path('teacherslogin/modifymarks/',views.modifymarks,name='modifymarks'),
    path('teacherslogin/modifymarks/modify_allsubjectmarks/',views.modify_allsubjectmarks),
    path('teacherslogin/modifymarks/modify_allsubjectmarks/updateallsubjectmarks/',views.updateallsubjectmarks),
]

